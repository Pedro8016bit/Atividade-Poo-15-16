﻿namespace Aplicativo_3
{
    partial class Tela_login
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_login));
            label1 = new Label();
            label2 = new Label();
            txt_email = new TextBox();
            txt_senha = new TextBox();
            btn_entrar = new Button();
            btn_esqueci = new LinkLabel();
            btn_cad = new LinkLabel();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(85, 83);
            label1.Name = "label1";
            label1.Size = new Size(32, 16);
            label1.TabIndex = 0;
            label1.Text = "Email";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(85, 142);
            label2.Name = "label2";
            label2.Size = new Size(38, 16);
            label2.TabIndex = 1;
            label2.Text = "Senha";
            // 
            // txt_email
            // 
            txt_email.Location = new Point(142, 83);
            txt_email.MaxLength = 100;
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(175, 22);
            txt_email.TabIndex = 1;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(142, 142);
            txt_senha.MaxLength = 100;
            txt_senha.Name = "txt_senha";
            txt_senha.PasswordChar = '*';
            txt_senha.Size = new Size(175, 22);
            txt_senha.TabIndex = 2;
            // 
            // btn_entrar
            // 
            btn_entrar.Location = new Point(142, 192);
            btn_entrar.Name = "btn_entrar";
            btn_entrar.Size = new Size(174, 25);
            btn_entrar.TabIndex = 3;
            btn_entrar.Text = "Entrar";
            btn_entrar.UseVisualStyleBackColor = true;
            btn_entrar.Click += btn_entrar_Click;
            // 
            // btn_esqueci
            // 
            btn_esqueci.AutoSize = true;
            btn_esqueci.Location = new Point(178, 219);
            btn_esqueci.Name = "btn_esqueci";
            btn_esqueci.Size = new Size(107, 16);
            btn_esqueci.TabIndex = 4;
            btn_esqueci.TabStop = true;
            btn_esqueci.Text = "Esqueci minha senha";
            // 
            // btn_cad
            // 
            btn_cad.AutoSize = true;
            btn_cad.Location = new Point(200, 245);
            btn_cad.Name = "btn_cad";
            btn_cad.Size = new Size(65, 16);
            btn_cad.TabIndex = 5;
            btn_cad.TabStop = true;
            btn_cad.Text = "Cadastre-se";
            btn_cad.LinkClicked += btn_cad_LinkClicked_1;
            // 
            // Tela_login
            // 
            AutoScaleDimensions = new SizeF(6F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(446, 327);
            Controls.Add(btn_cad);
            Controls.Add(btn_esqueci);
            Controls.Add(btn_entrar);
            Controls.Add(txt_senha);
            Controls.Add(txt_email);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial Narrow", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Tela_login";
            Text = "Tela_login";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txt_email;
        private TextBox txt_senha;
        private Button btn_entrar;
        private LinkLabel btn_esqueci;
        private LinkLabel btn_cad;
    }
}
