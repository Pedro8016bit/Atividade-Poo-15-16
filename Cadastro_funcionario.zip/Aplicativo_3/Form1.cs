using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Aplicativo_3
{
    public partial class Tela_login : Form
    {
        public Tela_login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }




        private void btn_cad_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Tela_cadastro telaCad = new Tela_cadastro();
            telaCad.Show();
            this.Hide();
        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txt_email.Text.Equals("") && !txt_senha.Text.Equals(""))
                {
                    Usuarios usuario = new Usuarios();
                    usuario.Senha = txt_senha.Text;
                    usuario.Email = txt_email.Text;

                    if (Usuarios.verificarEmail(txt_email.Text))
                    {
                        if (usuario.verificarLogin())
                        {

                            MessageBox.Show("login realizado com sucesso");
                            string nomeLogado = usuario.buscarNome();
                            Tela_sistema sist = new Tela_sistema(nomeLogado);
                            sist.Show();
                            this.Hide();
                            
                        }
                        else
                        {
                            MessageBox.Show("usuarios invalidos");
                        }
                    }
                    else
                    {
                        MessageBox.Show("erro no segundo else do try");
                    }
                }
                else
                {
                    MessageBox.Show("preencha os campos corretamente!!!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("n�o foi possivel acessar o sistema" + ex.Message);

            }
        }
    }
}
