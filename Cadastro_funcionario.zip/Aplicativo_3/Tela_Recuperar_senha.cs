﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicativo_3
{
    public partial class Tela_Recuperar_senha: Form
    {
        public Tela_Recuperar_senha()
        {
            InitializeComponent();
        }
    }
}
