﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Aplicativo_3
{
    public partial class Tela_cadastro : Form
    {
        public Tela_cadastro()
        {
            InitializeComponent();
        }

        private void btn_cadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txt_nome_2.Text.Equals("") && !txt_email_2.Text.Equals("") && !txt_senha_2.Text.Equals(""))
                {
                    Usuarios usuario = new Usuarios();
                    usuario.Nome = txt_nome_2.Text;
                    usuario.Email = txt_email_2.Text;
                    usuario.Senha = txt_senha_2.Text;

                    if (Usuarios.verificarEmail(txt_email_2.Text))
                    {
                        if (usuario.CadastrarUsuario())
                        {
                            MessageBox.Show("cadastro realizado");
                        }
                        else
                        {
                            MessageBox.Show("falha ao cadastrar user");
                        }
                    }
                    else
                    {
                        MessageBox.Show("insira um email valido");
                    }
                }
                else
                {
                    MessageBox.Show("prencha os campos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao cadastrar user:" + ex.Message);
            }
        }
    }
}
