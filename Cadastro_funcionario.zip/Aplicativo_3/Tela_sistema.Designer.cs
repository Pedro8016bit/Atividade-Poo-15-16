﻿namespace Aplicativo_3
{
    partial class Tela_sistema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lb_user = new Label();
            SuspendLayout();
            // 
            // lb_user
            // 
            lb_user.AutoSize = true;
            lb_user.Location = new Point(274, 154);
            lb_user.Name = "lb_user";
            lb_user.Size = new Size(0, 15);
            lb_user.TabIndex = 0;
            // 
            // Tela_sistema
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(589, 345);
            Controls.Add(lb_user);
            Name = "Tela_sistema";
            Text = "Tela_sistema";
            Load += Tela_sistema_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lb_user;
    }
}