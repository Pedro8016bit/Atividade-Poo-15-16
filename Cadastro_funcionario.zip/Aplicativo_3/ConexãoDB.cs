﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;

namespace Aplicativo_3
{
    public class ConexãoDB
    {
        //string para conexão com banco de dados
        private string conexaoBanco = "Server=localhost; Database=sistemaCadastro; Uid=root; Pwd=''";

        public MySqlConnection Conectar()
        {
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);
            conexao.Open();
            return conexao;
        }
    }
}
