﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aplicativo_3
{
    public partial class Tela_sistema : Form
    {
        private string Nomeusuario;
        public Tela_sistema(string nome)
        {
            InitializeComponent();
            Nomeusuario = nome;
        }

        private void Tela_sistema_Load(object sender, EventArgs e)
        {
            lb_user.Text = "Bem-vindo, " + Nomeusuario + "!";
        }
    }
}
