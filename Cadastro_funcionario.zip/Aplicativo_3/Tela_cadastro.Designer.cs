﻿namespace Aplicativo_3
{
    partial class Tela_cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txt_nome_2 = new TextBox();
            txt_email_2 = new TextBox();
            txt_senha_2 = new TextBox();
            btn_cadastrar = new Button();
            btn_tenho = new LinkLabel();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 66);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 0;
            label1.Text = "Nome:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 107);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 0;
            label2.Text = "E-mail:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(49, 151);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 0;
            label3.Text = "Senha:";
            // 
            // txt_nome_2
            // 
            txt_nome_2.Location = new Point(120, 66);
            txt_nome_2.Name = "txt_nome_2";
            txt_nome_2.Size = new Size(213, 23);
            txt_nome_2.TabIndex = 1;
            // 
            // txt_email_2
            // 
            txt_email_2.Location = new Point(120, 107);
            txt_email_2.Name = "txt_email_2";
            txt_email_2.Size = new Size(213, 23);
            txt_email_2.TabIndex = 2;
            // 
            // txt_senha_2
            // 
            txt_senha_2.Location = new Point(120, 148);
            txt_senha_2.Name = "txt_senha_2";
            txt_senha_2.Size = new Size(213, 23);
            txt_senha_2.TabIndex = 3;
            // 
            // btn_cadastrar
            // 
            btn_cadastrar.Location = new Point(120, 190);
            btn_cadastrar.Name = "btn_cadastrar";
            btn_cadastrar.Size = new Size(213, 23);
            btn_cadastrar.TabIndex = 4;
            btn_cadastrar.Text = "Cadastrar";
            btn_cadastrar.UseVisualStyleBackColor = true;
            btn_cadastrar.Click += btn_cadastrar_Click;
            // 
            // btn_tenho
            // 
            btn_tenho.AutoSize = true;
            btn_tenho.Location = new Point(171, 227);
            btn_tenho.Name = "btn_tenho";
            btn_tenho.Size = new Size(107, 15);
            btn_tenho.TabIndex = 5;
            btn_tenho.TabStop = true;
            btn_tenho.Text = "Já possui cadastro?";
            // 
            // Tela_cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(420, 287);
            Controls.Add(btn_tenho);
            Controls.Add(btn_cadastrar);
            Controls.Add(txt_senha_2);
            Controls.Add(txt_email_2);
            Controls.Add(txt_nome_2);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Tela_cadastro";
            Text = "Tela_cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txt_nome_2;
        private TextBox txt_email_2;
        private TextBox txt_senha_2;
        private Button btn_cadastrar;
        private LinkLabel btn_tenho;
    }
}