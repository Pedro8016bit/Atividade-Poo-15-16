﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cadastro_funcionario
{
    class Funcionarios
    {
        private int id;
        private string nome;
        private string cpf;
        private DateTime dataNascimento;
        private string cargo;
        private string setor;
        private decimal salario;
        private string sexo;
    }
}
