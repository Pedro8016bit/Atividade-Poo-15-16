﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.Cmp;

namespace Cadastro_funcionario
{
    class BancoDB
    {
        private string conexaoBanco = "Server=localhost; Database=CadastroFunc; Uid=root; Pwd''";

        public MySqlConnection conectar()
        {
            MySqlConnection conexao = new MySqlConnection(conexaoBanco);
            conexao.Open();
            return conexao;
        }
    }
}
